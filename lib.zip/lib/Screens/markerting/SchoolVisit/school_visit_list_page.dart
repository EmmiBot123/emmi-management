import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../../../Providers/Marketing/SchoolVisitProvider.dart';

import 'package:flutter/foundation.dart' show kIsWeb;

import 'add_visit_page.dart';
import 'visit_details_page.dart';

class SchoolVisitListPage extends StatefulWidget {
  final String userId;
  final String name;
  final String role;

  const SchoolVisitListPage({
    super.key,
    required this.userId,
    required this.name,
    required this.role,
  });

  @override
  State<SchoolVisitListPage> createState() => _SchoolVisitListPageState();
}

class _SchoolVisitListPageState extends State<SchoolVisitListPage> {
  @override
  void initState() {
    super.initState();
    Future.microtask(
        () => context.read<SchoolVisitProvider>().loadVisits(widget.userId));
  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
    Future.microtask(
        () => context.read<SchoolVisitProvider>().disableNearbyMode());
  }

  Widget _nearbyAppBarButton(BuildContext context) {
    final provider = context.watch<SchoolVisitProvider>();

    return IconButton(
      tooltip: "Nearby schools",
      icon: Icon(
        Icons.near_me,
        color: provider.isNearbyMode ? Colors.blue : Colors.grey,
      ),
      onPressed: () => _showRadiusDialog(provider),
    );
  }

  void _showRadiusDialog(SchoolVisitProvider provider) {
    showDialog(
      context: context,
      builder: (context) {
        double tempRadius = provider.nearbyRadiusKm;

        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              title: const Text("Nearby Schools"),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text("${tempRadius.toInt()} km radius"),
                  Slider(
                    value: tempRadius,
                    min: 1,
                    max: 600,
                    divisions: 60,
                    label: "${tempRadius.toInt()} km",
                    onChanged: (value) {
                      setState(() {
                        tempRadius = value;
                      });
                    },
                  ),
                ],
              ),
              actions: [
                TextButton(
                  onPressed: () {
                    provider.disableNearbyMode();
                    Navigator.pop(context);
                  },
                  child: const Text("CLEAR"),
                ),
                ElevatedButton(
                  onPressed: () async {
                    Navigator.pop(context);
                    await provider.enableNearbyMode(tempRadius);
                  },
                  child: const Text("APPLY"),
                ),
              ],
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<SchoolVisitProvider>();

    return WillPopScope(
      onWillPop: () async {
        provider.clear();
        return true;
      },
      child: Scaffold(
        appBar: AppBar(
          title: const Text("School Visits"),
          centerTitle: true,
          actions: [
            _nearbyAppBarButton(context),
            const SizedBox(width: 8),
          ],

          // keep existing WEB bottom filters if you want
          bottom: kIsWeb
              ? PreferredSize(
                  preferredSize: const Size.fromHeight(65),
                  child: _buildFilters(provider),
                )
              : null,
        ),

        // Filter bottom bar for MOBILE
        bottomNavigationBar: !kIsWeb
            ? Container(
                padding: const EdgeInsets.symmetric(vertical: 6),
                height: 65,
                decoration: BoxDecoration(
                  color: Colors.white,
                  boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 4)],
                ),
                child: _buildFilters(provider),
              )
            : null,

        floatingActionButton: FloatingActionButton.extended(
          icon: const Icon(Icons.add),
          label: const Text("Add Visit"),
          onPressed: () {
            print("role:${widget.role}");
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => AddVisitPage(
                  userId: widget.userId,
                  name: widget.name,
                  role: widget.role,
                ),
              ),
            );
          },
        ),

        body: provider.isLoading
            ? const Center(child: CircularProgressIndicator())
            : provider.filteredVisits.isEmpty
                ? const Center(
                    child: Text(
                      "No school visits recorded yet.\nClick + to add one.",
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 16),
                    ),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.all(12),
                    itemCount: provider.filteredVisits.length,
                    itemBuilder: (_, index) {
                      final visit = provider.filteredVisits[index];

                      return GestureDetector(
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => VisitDetailsPage(
                                visit: visit,
                                userId: widget.userId,
                                role: widget.role,
                              ),
                            ),
                          );
                        },
                        child: Card(
                          elevation: 3,
                          margin: const EdgeInsets.only(bottom: 12),
                          child: ListTile(
                            title: Text(
                              visit.schoolProfile.name,
                              style: const TextStyle(
                                  fontWeight: FontWeight.w600, fontSize: 16),
                            ),
                            subtitle: Text(
                              "Status: ${visit.visitDetails.status}\n"
                              "Revisit: ${visit.visitDetails.revisitDate ?? "Not Scheduled"}"
                              "${widget.role == "TELE_MARKETING" ? "\nAssigned To: ${visit.assignedUserName ?? "Not Assigned"}" : ""}"
                              "${widget.role == "MARKETING" ? "\nAssigned By: ${visit.createdByUserName ?? "Not Assigned"}" : ""}",
                            ),
                            trailing: IconButton(
                              icon: const Icon(Icons.delete, color: Colors.red),
                              onPressed: () async {
                                final confirm = await showDialog(
                                  context: context,
                                  builder: (_) => AlertDialog(
                                    title: const Text("Delete Entry"),
                                    content: const Text("Delete this entry?"),
                                    actions: [
                                      TextButton(
                                        onPressed: () => Navigator.of(context,
                                                rootNavigator: true)
                                            .pop(false),
                                        child: const Text("Cancel"),
                                      ),
                                      ElevatedButton(
                                        style: ElevatedButton.styleFrom(
                                            backgroundColor: Colors.red),
                                        onPressed: () => Navigator.of(context,
                                                rootNavigator: true)
                                            .pop(true),
                                        child: const Text("Delete"),
                                      ),
                                    ],
                                  ),
                                );

                                if (confirm == true) {
                                  print("in confirm");
                                  await provider.deleteVisit(visit.id!);
                                  if (visit.schoolProfile.photoUrl.isNotEmpty) {
                                    await provider.deleteVisit(visit.id!);
                                  }
                                  provider.deleteVisit(visit.id!);
                                  if (context.mounted) {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(
                                          content:
                                              Text("Deleted Successfully")),
                                    );
                                  }
                                }
                              },
                            ),
                          ),
                        ),
                      );
                    },
                  ),
      ),
    );
  }

  /// FILTER BUTTON WIDGET
  Widget _buildFilters(SchoolVisitProvider provider) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        _filterChip("ALL", Icons.list, provider),
        _filterChip("PENDING", Icons.pending_actions, provider),
        _filterChip("APPROVED", Icons.check_circle, provider),
        _filterChip("REJECTED", Icons.cancel, provider),
      ],
    );
  }

  Widget _filterChip(
      String label, IconData icon, SchoolVisitProvider provider) {
    final isSelected = provider.currentFilter == label;

    return GestureDetector(
      onTap: () => provider.filterByStatus(label),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            icon,
            size: 26,
            color: isSelected ? Colors.blue : Colors.grey,
          ),
          Text(
            label,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w600,
              color: isSelected ? Colors.blue : Colors.black,
            ),
          ),
        ],
      ),
    );
  }
}
